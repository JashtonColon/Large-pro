// Handles talking to the backend for login, registration and password reset.
//
// Right now it uses a FAKE backend (useFakeBackend = true) so the screens can
// be built and tested before the Express API routes exist. When the backend
// team adds the routes, set useFakeBackend to false and fill in the TODOs
// (add the `http` package: `flutter pub add http`).

class AuthException implements Exception {
  AuthException(this.message);
  final String message;

  @override
  String toString() => message;
}

class AuthService {
  // Android emulator -> server running on your PC: http://10.0.2.2:3000
  // Final demo -> your team's real domain, e.g. https://yourdomain.com
  static const String baseUrl = 'http://10.0.2.2:3000';
  static const bool useFakeBackend = true;

  static String? _token; // JWT from the server once logged in
  static String? currentUserEmail;

  static bool get isLoggedIn => _token != null;
  static String? get token => _token;

  static Future<void> login(String email, String password) async {
    if (useFakeBackend) {
      await _fakeDelay();
      // Fake rule so you can test the error message: wrong password = "wrong".
      if (password == 'wrong') {
        throw AuthException('Invalid email or password.');
      }
      _token = 'fake-jwt-token';
      currentUserEmail = email;
      return;
    }
    // TODO: POST $baseUrl/api/auth/login with {email, password}.
    // On success save the JWT from the response into _token.
    // If the server says the email isn't verified, throw AuthException.
    throw UnimplementedError();
  }

  static Future<void> register({
    required String firstName,
    required String lastName,
    required String email,
    required String password,
  }) async {
    if (useFakeBackend) {
      await _fakeDelay();
      if (email.toLowerCase() == 'taken@ucf.edu') {
        throw AuthException('An account with that email already exists.');
      }
      return;
    }
    // TODO: POST $baseUrl/api/auth/register. The server should send the
    // verification email; the user verifies before they can log in.
    throw UnimplementedError();
  }

  static Future<void> sendPasswordReset(String email) async {
    if (useFakeBackend) {
      await _fakeDelay();
      return;
    }
    // TODO: POST $baseUrl/api/auth/forgot-password with {email}.
    throw UnimplementedError();
  }

  static void logout() {
    _token = null;
    currentUserEmail = null;
  }

  static Future<void> _fakeDelay() =>
      Future.delayed(const Duration(milliseconds: 800));
}
