import 'package:flutter/material.dart';

import '../services/auth_service.dart';
import '../utils/validators.dart';
import '../widgets/auth_widgets.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  bool _loading = false;
  bool _sent = false;
  String? _error;

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await AuthService.sendPasswordReset(_emailController.text.trim());
      if (!mounted) return;
      setState(() => _sent = true);
    } on AuthException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_sent) {
      return AuthLayout(
        children: [
          AuthHeader(
            title: 'Check your email',
            subtitle: 'If an account exists for '
                '${_emailController.text.trim()}, '
                'we sent a link to reset your password.',
          ),
          const SizedBox(height: 32),
          LoadingButton(
            label: 'Back to log in',
            loading: false,
            onPressed: () => Navigator.pop(context),
          ),
        ],
      );
    }

    return AuthLayout(
      showBack: true,
      children: [
        const AuthHeader(
          title: 'Reset password',
          subtitle: "Enter your email and we'll send you a reset link",
        ),
        const SizedBox(height: 32),
        Form(
          key: _formKey,
          child: TextFormField(
            controller: _emailController,
            keyboardType: TextInputType.emailAddress,
            textInputAction: TextInputAction.done,
            onFieldSubmitted: (_) => _submit(),
            decoration: authInputDecoration('Email', Icons.email_outlined),
            validator: Validators.email,
          ),
        ),
        const SizedBox(height: 24),
        if (_error != null) ErrorBanner(message: _error!),
        LoadingButton(
            label: 'Send reset link', loading: _loading, onPressed: _submit),
      ],
    );
  }
}
