import 'package:flutter/material.dart';

import 'screens/forgot_password_screen.dart';
import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'screens/register_screen.dart';

// UCF gold.
const Color knightGold = Color(0xFFFFC904);

void main() {
  runApp(const StudyBuddyApp());
}

class StudyBuddyApp extends StatelessWidget {
  const StudyBuddyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: knightGold,
      brightness: Brightness.dark,
    ).copyWith(primary: knightGold, onPrimary: Colors.black);

    return MaterialApp(
      title: 'Knight Study Buddy',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorScheme: colorScheme),
      // The assignment requires users to land on log in / register first.
      initialRoute: '/login',
      routes: {
        '/login': (_) => const LoginScreen(),
        '/register': (_) => const RegisterScreen(),
        '/forgot-password': (_) => const ForgotPasswordScreen(),
        '/home': (_) => const HomeScreen(),
      },
    );
  }
}
